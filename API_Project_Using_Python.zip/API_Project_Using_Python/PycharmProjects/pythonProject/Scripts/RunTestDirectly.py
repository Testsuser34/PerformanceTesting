from locust import HttpUser, TaskSet, task, between


class API(TaskSet):

    @task
    def launch_URL(self):
        with self.client.get("/v1/Categories/6327/Details.json?catalogue=false", name="launchURL", catch_response=True) as resp1:
            #print(resp1.text)
            if ('"Name":"Carbon credits"' and '"Name":"Gallery","Description":"Good position in category"' and '"CanRelist":true') in resp1.text:
                resp1.success()
            else:
                resp1.failure("failed to launch url")


class MyUser(HttpUser):
    wait_time = between(1, 2)
    host = "https://api.tmsandbox.co.nz"
    tasks = [API]