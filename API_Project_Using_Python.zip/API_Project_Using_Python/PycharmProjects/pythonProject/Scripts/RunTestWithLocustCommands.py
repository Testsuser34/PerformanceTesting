import requests, json, operator

url = 'https://api.tmsandbox.co.nz/v1/Categories/6327/Details.json?catalogue=false'

def use_requests(url):
    response = requests.get(url)
    # res = response.text
    # print("+++++",response.text)
    # if operator.contains(response.text, '"Name":"Carbon credits"' and '"CanRelist":true' and '"Description":"Good position in category"'):
    #     print ("True")
    # else :
    #     print ("False")
    print("status code -->>",response.status_code,"\n")

    # Adding all 3 assertions one by one
    if operator.contains(response.text, '"Name":"Carbon credits"'):
        print ("First assertion pass")
    else :
        print ("First assertion Fail")

    if operator.contains(response.text, '"CanRelist":true'):
        print ("Second assertion pass")
    else :
        print ("Second assertion Fail")

    if operator.contains(response.text, '"Name":"Gallery","Description":"Good position in category"'):
        print ("Third assertion pass")
    else :
        print ("Third assertion Fail")
    return

use_requests(url)